<?php

function sessions_column_exists(PDO $pdo, string $column): bool {
  static $cache = [];
  if (isset($cache[$column])) {
    return $cache[$column];
  }

  $sql = "
    SELECT COUNT(*) AS c
    FROM information_schema.COLUMNS
    WHERE TABLE_SCHEMA = DATABASE()
      AND TABLE_NAME = 'sessions'
      AND COLUMN_NAME = ?
  ";
  $st = $pdo->prepare($sql);
  $st->execute([$column]);
  $cache[$column] = ((int)$st->fetchColumn() > 0);
  return $cache[$column];
}

function table_exists(PDO $pdo, string $table): bool {
  static $cache = [];
  if (isset($cache[$table])) {
    return $cache[$table];
  }

  $sql = "
    SELECT COUNT(*) AS c
    FROM information_schema.TABLES
    WHERE TABLE_SCHEMA = DATABASE()
      AND TABLE_NAME = ?
  ";
  $st = $pdo->prepare($sql);
  $st->execute([$table]);
  $cache[$table] = ((int)$st->fetchColumn() > 0);
  return $cache[$table];
}

function table_column_exists(PDO $pdo, string $table, string $column): bool {
  static $cache = [];
  $cacheKey = $table . ':' . $column;
  if (isset($cache[$cacheKey])) {
    return $cache[$cacheKey];
  }

  $sql = "
    SELECT COUNT(*) AS c
    FROM information_schema.COLUMNS
    WHERE TABLE_SCHEMA = DATABASE()
      AND TABLE_NAME = ?
      AND COLUMN_NAME = ?
  ";
  $st = $pdo->prepare($sql);
  $st->execute([$table, $column]);
  $cache[$cacheKey] = ((int)$st->fetchColumn() > 0);
  return $cache[$cacheKey];
}

function compute_package_selection_target(array $pkg, int $eligibleCount): int {
  $mode = strtoupper(trim((string)($pkg['selection_mode'] ?? 'COUNT')));
  if ($mode === 'PERCENT') {
    $percent = (int)($pkg['selection_percent'] ?? 0);
    if ($percent < 1) {
      $percent = 1;
    }
    if ($percent > 100) {
      $percent = 100;
    }
    $target = (int)ceil(($eligibleCount * $percent) / 100);
    return max(1, $target);
  }

  $count = (int)($pkg['selection_count'] ?? 0);
  if ($count < 1) {
    $count = 1;
  }
  return $count;
}

function recent_question_ids_for_user_package(PDO $pdo, int $userId, int $packageId, int $sessionLimit = 4): array {
  if ($userId <= 0 || $packageId <= 0 || $sessionLimit < 1) {
    return [];
  }

  $sql = "
    SELECT DISTINCT sq.question_id
    FROM session_questions sq
    JOIN (
      SELECT id
      FROM sessions
      WHERE user_id = ?
        AND package_id = ?
        AND status IN ('TERMINATED', 'EXPIRED')
      ORDER BY started_at DESC
      LIMIT " . (int)$sessionLimit . "
    ) recent ON recent.id = sq.session_id
  ";
  $st = $pdo->prepare($sql);
  $st->execute([$userId, $packageId]);
  $rows = $st->fetchAll() ?: [];
  $ids = [];
  foreach ($rows as $row) {
    $ids[] = (int)($row['question_id'] ?? 0);
  }
  $ids = array_values(array_unique(array_filter($ids, fn($v) => $v > 0)));
  return $ids;
}

function reorder_questions_for_session(PDO $pdo, array $qids): array {
  $qids = array_values(array_unique(array_map('intval', $qids)));
  if (count($qids) <= 1) {
    return $qids;
  }

  if (!table_column_exists($pdo, 'questions', 'theme')) {
    shuffle($qids);
    return $qids;
  }

  $placeholders = implode(',', array_fill(0, count($qids), '?'));
  $sql = "
    SELECT id, COALESCE(NULLIF(TRIM(theme), ''), '__none__') AS theme_key
    FROM questions
    WHERE id IN ($placeholders)
  ";
  $st = $pdo->prepare($sql);
  $st->execute($qids);
  $rows = $st->fetchAll() ?: [];

  $groups = [];
  foreach ($rows as $row) {
    $id = (int)($row['id'] ?? 0);
    if ($id <= 0) {
      continue;
    }
    $theme = (string)($row['theme_key'] ?? '__none__');
    if (!isset($groups[$theme])) {
      $groups[$theme] = [];
    }
    $groups[$theme][] = $id;
  }

  if (!$groups) {
    shuffle($qids);
    return $qids;
  }

  foreach ($groups as &$ids) {
    shuffle($ids);
  }
  unset($ids);

  $ordered = [];
  while (!empty($groups)) {
    $themes = array_keys($groups);
    shuffle($themes);
    foreach ($themes as $theme) {
      if (empty($groups[$theme])) {
        continue;
      }
      $ordered[] = array_shift($groups[$theme]);
      if (empty($groups[$theme])) {
        unset($groups[$theme]);
      }
    }
  }

  // Keep only ids from the original selection and complete if needed.
  $allowed = array_fill_keys($qids, true);
  $ordered = array_values(array_filter($ordered, fn($id) => isset($allowed[$id])));
  if (count($ordered) < count($qids)) {
    $seen = array_fill_keys($ordered, true);
    foreach ($qids as $id) {
      if (!isset($seen[$id])) {
        $ordered[] = $id;
      }
    }
  }

  return $ordered;
}

function select_questions_for_package(PDO $pdo, array $pkg, int $userId = 0): array {
  $packageId = (int)($pkg['id'] ?? 0);
  if ($packageId <= 0) {
    return ['ids' => [], 'error_key' => 'start.err.invalid_package'];
  }

  $limit = (int)($pkg['selection_count'] ?? 0);
  if ($limit < 1) {
    $limit = 1;
  }

  $hasNeed = table_column_exists($pdo, 'questions', 'need');
  $hasLevel = table_column_exists($pdo, 'questions', 'level');
  $antiRepeatSessions = 1;
  $recentExcludedQids = $antiRepeatSessions > 0
    ? recent_question_ids_for_user_package($pdo, $userId, $packageId, $antiRepeatSessions)
    : [];

  // Legacy bucket rules can drive distribution, but package count stays authoritative.
  $raw = $pkg['selection_rules_json'] ?? null;
  if ($hasNeed && $hasLevel && is_string($raw) && trim($raw) !== '') {
    $rules = json_decode($raw, true);
    if (is_array($rules) && !empty($rules['buckets']) && is_array($rules['buckets'])) {
      // Package settings are authoritative for the total number of questions.
      // Legacy JSON `max` is ignored to keep admin package config effective.
      $max = $limit;

      $qids = [];
      foreach ($rules['buckets'] as $bucket) {
        if (count($qids) >= $max) {
          break;
        }

        $need = strtoupper(trim((string)($bucket['need'] ?? '')));
        $levels = $bucket['levels'] ?? [];
        $take = (int)($bucket['take'] ?? 0);
        $targetTotal = (int)($bucket['target_total'] ?? 0);

        if (!in_array($need, ['PONE', 'PHM', 'PPM'], true) || !is_array($levels) || $take <= 0) {
          continue;
        }

        $levels = array_values(array_unique(array_map('intval', $levels)));
        $levels = array_values(array_filter($levels, fn($x) => $x >= 1 && $x <= 9));
        if (!$levels) {
          continue;
        }

        $remaining = $max - count($qids);
        if ($take > $remaining) {
          $take = $remaining;
        }
        if ($targetTotal > 0) {
          $remainingToTarget = $targetTotal - count($qids);
          if ($remainingToTarget <= 0) {
            continue;
          }
          if ($take > $remainingToTarget) {
            $take = $remainingToTarget;
          }
        }
        if ($take <= 0) {
          continue;
        }

        $inLevels = implode(',', array_fill(0, count($levels), '?'));
        $sql = "
          SELECT q.id
          FROM questions q
          JOIN question_options qo ON qo.question_id = q.id
          WHERE q.need = ?
            AND q.level IN ($inLevels)
        ";
        $params = array_merge([$need], $levels);

        $excludedNow = array_values(array_unique(array_merge($qids, $recentExcludedQids)));
        if (!empty($excludedNow)) {
          $inExclude = implode(',', array_fill(0, count($excludedNow), '?'));
          $sql .= " AND q.id NOT IN ($inExclude)";
          $params = array_merge($params, array_map('intval', $excludedNow));
        }

        $sql .= "
          GROUP BY q.id
          HAVING COUNT(qo.id) >= 2
          ORDER BY RAND()
          LIMIT " . (int)$take;

        $st = $pdo->prepare($sql);
        $st->execute($params);
        $rows = $st->fetchAll() ?: [];
        foreach ($rows as $row) {
          $qids[] = (int)$row['id'];
        }

        // Soft anti-repeat: if strict exclusion cannot fill the bucket, top up without recent exclusion.
        if (count($rows) < $take) {
          $missing = $take - count($rows);
          $sqlFill = "
            SELECT q.id
            FROM questions q
            JOIN question_options qo ON qo.question_id = q.id
            WHERE q.need = ?
              AND q.level IN ($inLevels)
          ";
          $paramsFill = array_merge([$need], $levels);
          if (!empty($qids)) {
            $inExcludeFill = implode(',', array_fill(0, count($qids), '?'));
            $sqlFill .= " AND q.id NOT IN ($inExcludeFill)";
            $paramsFill = array_merge($paramsFill, array_map('intval', $qids));
          }
          $sqlFill .= "
            GROUP BY q.id
            HAVING COUNT(qo.id) >= 2
            ORDER BY RAND()
            LIMIT " . (int)$missing;
          $stFill = $pdo->prepare($sqlFill);
          $stFill->execute($paramsFill);
          $rowsFill = $stFill->fetchAll() ?: [];
          foreach ($rowsFill as $rowFill) {
            $qids[] = (int)$rowFill['id'];
          }
        }
      }

      if (count($qids) < $max) {
        return ['ids' => [], 'error_key' => 'start.err.not_enough_tagged'];
      }

      if (count($qids) > $max) {
        $qids = array_slice($qids, 0, $max);
      }

      $qids = reorder_questions_for_session($pdo, $qids);
      return ['ids' => $qids, 'error_key' => null];
    }
  }

  // Legacy fallback: package-local random selection by selection_count.
  $sql = "
    SELECT q.id
    FROM questions q
    JOIN question_options qo ON qo.question_id = q.id
    WHERE q.package_id = ?
  ";
  $params = [$packageId];
  if (!empty($recentExcludedQids)) {
    $inExclude = implode(',', array_fill(0, count($recentExcludedQids), '?'));
    $sql .= " AND q.id NOT IN ($inExclude)";
    $params = array_merge($params, array_map('intval', $recentExcludedQids));
  }
  $sql .= "
    GROUP BY q.id
    HAVING COUNT(qo.id) >= 2
    ORDER BY RAND()
    LIMIT " . (int)$limit;
  $st = $pdo->prepare($sql);
  $st->execute($params);
  $rows = $st->fetchAll() ?: [];
  $qids = array_map(fn($r) => (int)$r['id'], $rows);

  if (count($qids) < $limit && !empty($recentExcludedQids)) {
    $missing = $limit - count($qids);
    $sqlFill = "
      SELECT q.id
      FROM questions q
      JOIN question_options qo ON qo.question_id = q.id
      WHERE q.package_id = ?
    ";
    $paramsFill = [$packageId];
    if (!empty($qids)) {
      $inExcludeFill = implode(',', array_fill(0, count($qids), '?'));
      $sqlFill .= " AND q.id NOT IN ($inExcludeFill)";
      $paramsFill = array_merge($paramsFill, array_map('intval', $qids));
    }
    $sqlFill .= "
      GROUP BY q.id
      HAVING COUNT(qo.id) >= 2
      ORDER BY RAND()
      LIMIT " . (int)$missing;
    $stFill = $pdo->prepare($sqlFill);
    $stFill->execute($paramsFill);
    $rowsFill = $stFill->fetchAll() ?: [];
    foreach ($rowsFill as $rowFill) {
      $qids[] = (int)$rowFill['id'];
    }
  }

  if (count($qids) < $limit) {
    return ['ids' => [], 'error_key' => 'start.err.not_enough_package'];
  }

  $qids = reorder_questions_for_session($pdo, $qids);
  return ['ids' => $qids, 'error_key' => null];
}

function compute_score_percent_from_raw(int $rawScore, int $maxPoints): float {
  if ($maxPoints <= 0) {
    return 0.0;
  }

  $ratio = $rawScore / $maxPoints;
  if ($ratio < 0) {
    $ratio = 0;
  }
  if ($ratio > 1) {
    $ratio = 1;
  }

  return $ratio * 100.0;
}

function compute_session_score_snapshot(PDO $pdo, string $sessionId): array {
  // Max is 1 point per question in the session.
  $maxStmt = $pdo->prepare("
    SELECT COUNT(*) AS max_points
    FROM session_questions sq
    WHERE sq.session_id=?
  ");
  $maxStmt->execute([$sessionId]);
  $maxPoints = (int)($maxStmt->fetch()['max_points'] ?? 0);

  // Raw score follows exact-match business rules:
  // +1 if all and only correct answers are selected for a question, otherwise 0.
  $rawStmt = $pdo->prepare("
    SELECT COALESCE(SUM(
      CASE
        WHEN COALESCE(ans.selected_correct_count, 0) = qstats.correct_count
         AND COALESCE(ans.selected_total_count, 0) = qstats.correct_count
        THEN 1
        ELSE 0
      END
    ), 0) AS raw_score
    FROM (
      SELECT
        sq.question_id,
        COUNT(CASE WHEN qo.is_correct = 1 THEN 1 END) AS correct_count
      FROM session_questions sq
      JOIN question_options qo ON qo.question_id = sq.question_id
      WHERE sq.session_id=?
      GROUP BY sq.question_id
    ) qstats
    LEFT JOIN (
      SELECT
        ao.question_id,
        COUNT(*) AS selected_total_count,
        COUNT(CASE WHEN qo.is_correct = 1 THEN 1 END) AS selected_correct_count
      FROM answer_options ao
      JOIN question_options qo ON qo.id = ao.option_id
      WHERE ao.session_id=?
      GROUP BY ao.question_id
    ) ans ON ans.question_id = qstats.question_id
  ");
  $rawStmt->execute([$sessionId, $sessionId]);
  $rawScore = (int)($rawStmt->fetch()['raw_score'] ?? 0);

  $scorePercent = compute_score_percent_from_raw($rawScore, $maxPoints);

  return [
    'raw_score' => $rawScore,
    'max_points' => $maxPoints,
    'score_percent' => $scorePercent,
  ];
}

function refresh_active_session_score(PDO $pdo, string $sessionId): float {
  $snapshot = compute_session_score_snapshot($pdo, $sessionId);
  $scorePercent = round((float)($snapshot['score_percent'] ?? 0.0), 2);
  $pdo->prepare("UPDATE sessions SET score_percent=? WHERE id=? AND status='ACTIVE'")
      ->execute([$scorePercent, $sessionId]);
  return $scorePercent;
}

function create_session_record(
  PDO $pdo,
  string $sessionId,
  int $contactId,
  int $userId,
  int $packageId,
  string $sessionType,
  string $language
): void {
  $hasLanguage = sessions_column_exists($pdo, 'language');

  if ($hasLanguage) {
    $sql = "
      INSERT INTO sessions(id, contact_id, user_id, package_id, session_type, language)
      VALUES(?,?,?,?,?,?)
    ";
    $pdo->prepare($sql)->execute([$sessionId, $contactId, $userId, $packageId, $sessionType, $language]);
    return;
  }

  $sql = "
    INSERT INTO sessions(id, contact_id, user_id, package_id, session_type)
    VALUES(?,?,?,?,?)
  ";
  $pdo->prepare($sql)->execute([$sessionId, $contactId, $userId, $packageId, $sessionType]);
}

function mark_session_terminated(
  PDO $pdo,
  string $sessionId,
  float $scorePercent,
  int $passed,
  string $terminationType = 'MANUAL'
): void {
  $hasEndedAt = sessions_column_exists($pdo, 'ended_at');
  $hasTerminationType = sessions_column_exists($pdo, 'termination_type');
  $terminationType = strtoupper(trim($terminationType));
  if (!in_array($terminationType, ['MANUAL', 'TIMEOUT'], true)) {
    $terminationType = 'MANUAL';
  }

  $sets = ["status='TERMINATED'", "submitted_at=NOW()", "score_percent=?", "passed=?"];
  if ($hasEndedAt) {
    $sets[] = "ended_at=NOW()";
  }
  if ($hasTerminationType) {
    $sets[] = "termination_type='" . $terminationType . "'";
  }

  $sql = "UPDATE sessions SET " . implode(', ', $sets) . " WHERE id=?";
  $pdo->prepare($sql)->execute([$scorePercent, $passed, $sessionId]);
}

function mark_session_expired(PDO $pdo, string $sessionId): void {
  $hasEndedAt = sessions_column_exists($pdo, 'ended_at');
  $hasTerminationType = sessions_column_exists($pdo, 'termination_type');

  $sets = ["status='EXPIRED'"];
  if ($hasEndedAt) {
    $sets[] = "ended_at=NOW()";
  }
  if ($hasTerminationType) {
    $sets[] = "termination_type='TIMEOUT'";
  }

  $sql = "UPDATE sessions SET " . implode(', ', $sets) . " WHERE id=? AND status='ACTIVE'";
  $pdo->prepare($sql)->execute([$sessionId]);
}

function session_is_expired(array $session, ?DateTimeImmutable $now = null): bool {
  if (($session['status'] ?? '') !== 'ACTIVE') {
    return false;
  }

  $startedAt = (string)($session['started_at'] ?? '');
  if ($startedAt === '') {
    return false;
  }

  $limitMinutes = (int)($session['duration_limit_minutes'] ?? 120);
  if ($limitMinutes < 1) {
    $limitMinutes = 1;
  }

  $started = new DateTimeImmutable($startedAt);
  $expires = $started->modify("+{$limitMinutes} minutes");
  $now = $now ?: new DateTimeImmutable('now');

  return $now > $expires;
}

function certification_status_from_last_success(
  ?string $lastSuccessAt,
  ?DateTimeImmutable $now = null,
  int $validityDays = 365
): array {
  if ($lastSuccessAt === null || trim($lastSuccessAt) === '') {
    return [
      'status_key' => 'NONE',
      'status_label' => 'Aucune',
      'status_class' => 'pill',
      'expires_at' => null,
    ];
  }

  if ($validityDays < 1) {
    $validityDays = 1;
  } elseif ($validityDays > 3650) {
    $validityDays = 3650;
  }

  $now = $now ?: new DateTimeImmutable('today');
  $last = new DateTimeImmutable($lastSuccessAt);
  $expires = $last->modify('+' . $validityDays . ' days');
  $soonLimit = $now->modify('+30 days');

  if ($expires < $now) {
    return [
      'status_key' => 'EXPIRED',
      'status_label' => 'Expire',
      'status_class' => 'pill danger',
      'expires_at' => $expires,
    ];
  }

  if ($expires <= $soonLimit) {
    return [
      'status_key' => 'SOON',
      'status_label' => 'Expire bientot',
      'status_class' => 'pill warning',
      'expires_at' => $expires,
    ];
  }

  return [
    'status_key' => 'CERTIFIED',
    'status_label' => 'Certifié',
    'status_class' => 'pill success',
    'expires_at' => $expires,
  ];
}

function failed_exam_cooldown_status_from_last_failure(
  ?string $lastFailedAt,
  ?DateTimeImmutable $now = null,
  int $cooldownDays = 0
): array {
  if ($lastFailedAt === null || trim($lastFailedAt) === '' || $cooldownDays <= 0) {
    return [
      'status_key' => 'AVAILABLE',
      'available_at' => null,
      'remaining_days' => 0,
    ];
  }

  if ($cooldownDays > 3650) {
    $cooldownDays = 3650;
  }

  $now = $now ?: new DateTimeImmutable('today');
  $last = new DateTimeImmutable($lastFailedAt);
  $availableAt = $last->modify('+' . $cooldownDays . ' days');

  if ($availableAt <= $now) {
    return [
      'status_key' => 'AVAILABLE',
      'available_at' => $availableAt,
      'remaining_days' => 0,
    ];
  }

  $remainingDays = (int)$now->diff($availableAt)->format('%a');
  if ($remainingDays < 1) {
    $remainingDays = 1;
  }

  return [
    'status_key' => 'COOLDOWN',
    'available_at' => $availableAt,
    'remaining_days' => $remainingDays,
  ];
}
