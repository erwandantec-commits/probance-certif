<?php
echo "OK PHP";